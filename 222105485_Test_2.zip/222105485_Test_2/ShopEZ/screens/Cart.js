import { StyleSheet, Text, View, FlatList, Image, TouchableOpacity, Alert, ActivityIndicator, StatusBar } from 'react-native'
import React, { useEffect, useState } from 'react'
import { auth, database } from '../firebaseConfig'
import { ref, onValue, remove, update } from 'firebase/database'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { Ionicons } from '@expo/vector-icons'
import { SafeAreaView } from 'react-native'

const Cart = () => {
  const [cartItems, setCartItems] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadCart()
  }, [])

  const loadCart = async () => {
    try {
      const userId = auth.currentUser.uid
      const cartRef = ref(database, `carts/${userId}`)

      onValue(cartRef, async (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.val()
          const items = Object.keys(data).map(key => ({
            key: key,
            ...data[key]
          }))
          setCartItems(items)
          await AsyncStorage.setItem(`cart_${userId}`, JSON.stringify(items))
          setLoading(false)
        } else {
          const cartString = await AsyncStorage.getItem(`cart_${userId}`)
          if (cartString) {
            setCartItems(JSON.parse(cartString))
          } else {
            setCartItems([])
          }
          setLoading(false)
        }
      }, async (error) => {
        const userId = auth.currentUser.uid
        const cartString = await AsyncStorage.getItem(`cart_${userId}`)
        if (cartString) {
          setCartItems(JSON.parse(cartString))
        }
        setLoading(false)
      })
    } catch (error) {
      Alert.alert("Error", "Failed to load cart")
      setLoading(false)
    }
  }

  const updateQuantity = async (item, newQuantity) => {
    if (newQuantity < 1) return

    try {
      const userId = auth.currentUser.uid
      const itemRef = ref(database, `carts/${userId}/${item.key}`)
      
      await update(itemRef, { quantity: newQuantity })

      const updatedItems = cartItems.map(cartItem =>
        cartItem.key === item.key ? { ...cartItem, quantity: newQuantity } : cartItem
      )
      setCartItems(updatedItems)
      await AsyncStorage.setItem(`cart_${userId}`, JSON.stringify(updatedItems))
    } catch (error) {
      Alert.alert("Error", "Failed to update quantity")
    }
  }

  const removeItem = async (item) => {
    Alert.alert(
      "Remove Item",
      "Are you sure you want to remove this item?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: async () => {
            try {
              const userId = auth.currentUser.uid
              const itemRef = ref(database, `carts/${userId}/${item.key}`)
              
              await remove(itemRef)

              const updatedItems = cartItems.filter(cartItem => cartItem.key !== item.key)
              setCartItems(updatedItems)
              await AsyncStorage.setItem(`cart_${userId}`, JSON.stringify(updatedItems))
            } catch (error) {
              Alert.alert("Error", "Failed to remove item")
            }
          }
        }
      ]
    )
  }

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0).toFixed(2)
  }

  const renderCartItem = ({ item }) => (
    <View style={styles.cartItem}>
      <Image source={{ uri: item.image }} style={styles.itemImage} />
      <View style={styles.itemDetails}>
        <Text style={styles.itemTitle} numberOfLines={2}>{item.title}</Text>
        <Text style={styles.itemPrice}>${item.price.toFixed(2)}</Text>
        <Text style={styles.subtotal}>Subtotal: ${(item.price * item.quantity).toFixed(2)}</Text>
      </View>
      <View style={styles.rightContainer}>
        <View style={styles.quantityContainer}>
          <TouchableOpacity
            style={styles.quantityButton}
            onPress={() => updateQuantity(item, item.quantity - 1)}
          >
            <Text style={styles.quantityButtonText}>-</Text>
          </TouchableOpacity>
          <Text style={styles.quantityText}>{item.quantity}</Text>
          <TouchableOpacity
            style={styles.quantityButton}
            onPress={() => updateQuantity(item, item.quantity + 1)}
          >
            <Text style={styles.quantityButtonText}>+</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={styles.removeButton} onPress={() => removeItem(item)}>
          <Ionicons name="trash-outline" size={24} color="#FF3B30" />
        </TouchableOpacity>
      </View>
    </View>
  )

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
      </View>
    )
  }

  if (cartItems.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>Your cart is empty</Text>
        <Ionicons name="cart-outline" size={80} color="#aaaaaa" style={{ marginTop: 20 }}/>
      </View>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
      <FlatList
        data={cartItems}
        renderItem={renderCartItem}
        keyExtractor={(item) => item.key}
        contentContainerStyle={styles.listContainer}
      />
      <View style={styles.totalContainer}>
        <Text style={styles.totalLabel}>Total:</Text>
        <Text style={styles.totalAmount}>${calculateTotal()}</Text>
      </View>
      <TouchableOpacity style={styles.checkoutButton}>
        <Text style={styles.checkoutButtonText}>Checkout</Text>
      </TouchableOpacity>
    </SafeAreaView>
  )
}

export default Cart

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5'
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5'
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5'
  },
  emptyText: {
    fontSize: 20,
    color: '#666666',
    fontWeight: '600',
  },
  listContainer: {
    padding: 15
  },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderRadius: 12,
    padding: 15,
    marginBottom: 10,
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: '#eeeeee',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  itemImage: {
    width: 70,
    height: 70,
    resizeMode: 'contain',
    marginRight: 15,
    backgroundColor: '#f9f9f9',
    borderRadius: 8
  },
  itemDetails: {
    flex: 1
  },
  rightContainer: {
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: 70
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 5,
    color: '#333333'
  },
  itemPrice: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#007AFF',
  },
  subtotal: {
    fontSize: 13,
    color: '#666666',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5
  },
  quantityButton: {
    width: 28,
    height: 28,
    backgroundColor: '#e0e0e0',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
  },
  quantityButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333333'
  },
  quantityText: {
    fontSize: 16,
    fontWeight: '600',
    marginHorizontal: 12,
    color: '#333333'
  },
  removeButton: {
    padding: 5,
    marginRight: -5,
  },
  totalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#ffffff',
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#eeeeee',
  },
  totalLabel: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333333'
  },
  totalAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#007AFF'
  },
  checkoutButton: {
    backgroundColor: '#007AFF',
    marginHorizontal: 15,
    height: 54,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 4,
  },
  checkoutButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '700'
  }
})