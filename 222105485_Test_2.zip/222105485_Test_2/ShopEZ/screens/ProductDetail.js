import { StyleSheet, Text, View, Image, ScrollView, TouchableOpacity, Alert, ActivityIndicator, StatusBar } from 'react-native'
import React, { useState } from 'react'
import { auth, database } from '../firebaseConfig'
import { ref, push } from 'firebase/database'
import { SafeAreaView } from 'react-native'

const ProductDetail = ({ route, navigation }) => {
    const { product } = route.params
    const [addingToCart, setAddingToCart] = useState(false)

    navigation.setOptions({
        headerStyle: {
            backgroundColor: '#ffffff',
        },
        headerTintColor: '#333333',
        title: product.title.substring(0, 20) + '...'
    })

    const handleAddToCart = async () => {
        if (!auth.currentUser) {
            Alert.alert("Error", "You must be logged in to add items to the cart.")
            return
        }

        setAddingToCart(true)
        try {
            const userId = auth.currentUser.uid
            const cartRef = ref(database, `carts/${userId}`)

            const cartItem = {
                title: product.title,
                price: product.price,
                image: product.image,
                quantity: 1,
                productId: product.id,
            }

            await push(cartRef, cartItem)

            Alert.alert("Success", `${product.title} added to cart!`)
        } catch (error) {
            Alert.alert("Error", "Failed to add item to cart: " + error.message)
        } finally {
            setAddingToCart(false)
        }
    }

    return (
        <SafeAreaView style={styles.container}>
            <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
            <ScrollView style={styles.scrollContainer}>
                <Image source={{ uri: product.image }} style={styles.productImage} />
                <View style={styles.detailsContainer}>
                    <Text style={styles.title}>{product.title}</Text>
                    <Text style={styles.price}>${product.price.toFixed(2)}</Text>
                    <Text style={styles.category}>Category: {product.category.charAt(0).toUpperCase() + product.category.slice(1)}</Text>
                    <Text style={styles.descriptionHeader}>Description</Text>
                    <Text style={styles.description}>{product.description}</Text>

                    <TouchableOpacity
                        style={[styles.addToCartButton, addingToCart && styles.addToCartButtonDisabled]}
                        onPress={handleAddToCart}
                        disabled={addingToCart}
                    >
                        {addingToCart ? (
                            <ActivityIndicator color="#ffffff" />
                        ) : (
                            <Text style={styles.addToCartButtonText}>Add to Cart</Text>
                        )}
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </SafeAreaView>
    )
}

export default ProductDetail

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#ffffff',
    },
    scrollContainer: {
        flex: 1,
    },
    productImage: {
        width: '100%',
        height: 350,
        resizeMode: 'contain',
        backgroundColor: '#f5f5f5',
        borderBottomLeftRadius: 10,
        borderBottomRightRadius: 10,
    },
    detailsContainer: {
        padding: 20,
    },
    title: {
        fontSize: 24,
        fontWeight: '700',
        marginBottom: 10,
        color: '#333333'
    },
    price: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#FF9500',
        marginBottom: 15,
    },
    category: {
        fontSize: 16,
        color: '#666666',
        marginBottom: 15,
        fontWeight: '500',
    },
    descriptionHeader: {
        fontSize: 18,
        fontWeight: '600',
        marginTop: 10,
        marginBottom: 8,
        color: '#333333'
    },
    description: {
        fontSize: 16,
        lineHeight: 24,
        color: '#666666',
        marginBottom: 40,
    },
    addToCartButton: {
        backgroundColor: '#007AFF',
        height: 54,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
        elevation: 3,
    },
    addToCartButtonDisabled: {
        opacity: 0.6,
    },
    addToCartButtonText: {
        color: '#ffffff',
        fontSize: 18,
        fontWeight: '700',
    },
})