import { StyleSheet, Text, View, ActivityIndicator, StatusBar } from 'react-native'
import React from 'react'
import { SafeAreaView } from 'react-native'

const Landing = ({ navigation }) => {
    return (
        <SafeAreaView style={styles.container}>
            <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
            
            <View style={styles.content}>
                <Text style={styles.welcomeText}>ShopEZ</Text>
                
                <Text style={styles.tagline}>
                    Your easiest path to online shopping.
                </Text>

                <View style={styles.infoBox}>
                    <Text style={styles.infoTitle}>Discover Quality Products</Text>
                    <Text style={styles.infoText}>
                        ShopEZ offers a curated selection of electronics, jewelry, men's and women's clothing—all at unbeatable prices.
                    </Text>
                    <Text style={styles.infoText}>
                        Sign in to explore our full catalog and manage your cart seamlessly.
                    </Text>
                </View>

                {/* Optional: Show loading indicator while authentication status is being checked */}
                <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color="#007AFF" />
                    <Text style={styles.loadingText}>Loading store...</Text>
                </View>
            </View>
        </SafeAreaView>
    )
}

export default Landing

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#ffffff',
    },
    content: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 30,
    },
    welcomeText: {
        fontSize: 50,
        fontWeight: '900',
        marginBottom: 10,
        color: '#333333',
    },
    tagline: {
        fontSize: 18,
        fontWeight: '500',
        marginBottom: 80,
        color: '#007AFF',
    },
    infoBox: {
        width: '100%',
        padding: 20,
        backgroundColor: '#f9f9f9',
        borderRadius: 12,
        marginBottom: 50,
        borderWidth: 1,
        borderColor: '#e0e0e0',
    },
    infoTitle: {
        fontSize: 20,
        fontWeight: '700',
        marginBottom: 10,
        color: '#333333',
        textAlign: 'center',
    },
    infoText: {
        fontSize: 16,
        lineHeight: 24,
        color: '#666666',
        marginBottom: 10,
        textAlign: 'center',
    },
    loadingContainer: {
        position: 'absolute',
        bottom: 50,
        alignItems: 'center',
    },
    loadingText: {
        marginTop: 10,
        fontSize: 14,
        color: '#666666',
    }
})