import { StyleSheet, Text, View, FlatList, ActivityIndicator, Image, TouchableOpacity, Alert, StatusBar } from 'react-native'
import React, { useState, useEffect } from 'react'
import { Ionicons } from '@expo/vector-icons'
import { auth } from '../firebaseConfig'
import { SafeAreaView } from 'react-native'

const Products = ({ navigation }) => {
    const [products, setProducts] = useState([])
    const [loading, setLoading] = useState(true)
    const [categories, setCategories] = useState([])
    const [selectedCategory, setSelectedCategory] = useState('all')

    useEffect(() => {
        fetchCategories()
        fetchProducts()
    }, [selectedCategory])

    const fetchCategories = async () => {
        try {
            const response = await fetch('https://fakestoreapi.com/products/categories')
            const data = await response.json()
            setCategories(['all', ...data])
        } catch (error) {
            console.error(error)
        }
    }

    const fetchProducts = async () => {
        setLoading(true)
        try {
            let url = 'https://fakestoreapi.com/products'
            if (selectedCategory !== 'all') {
                url = `https://fakestoreapi.com/products/category/${selectedCategory}`
            }
            const response = await fetch(url)
            const data = await response.json()
            setProducts(data)
        } catch (error) {
            Alert.alert("Error", "Failed to fetch products.")
        } finally {
            setLoading(false)
        }
    }

    const handleLogout = async () => {
        try {
            await auth.signOut()
        } catch (error) {
            Alert.alert("Logout Error", error.message)
        }
    }

    useEffect(() => {
        navigation.setOptions({
            headerStyle: {
                backgroundColor: '#ffffff',
            },
            headerTintColor: '#333333',
            headerRight: () => (
                <View style={{ flexDirection: 'row', marginRight: 10 }}>
                    <TouchableOpacity onPress={() => navigation.navigate('Cart')} style={{ marginRight: 15 }}>
                        <Ionicons name="cart-outline" size={24} color="#007AFF" /> {/* Blue accent */}
                    </TouchableOpacity>
                    <TouchableOpacity onPress={handleLogout}>
                        <Ionicons name="log-out-outline" size={24} color="#FF3B30" /> {/* Red for logout */}
                    </TouchableOpacity>
                </View>
            ),
            title: "ShopEZ Products"
        })
    }, [navigation])


    const renderProduct = ({ item }) => (
        <TouchableOpacity
            style={styles.productItem}
            onPress={() => navigation.navigate('ProductDetail', { product: item })}
        >
            <Image source={{ uri: item.image }} style={styles.productImage} />
            <View style={styles.productInfo}>
                <Text style={styles.productTitle} numberOfLines={2}>{item.title}</Text>
                <Text style={styles.productPrice}>${item.price.toFixed(2)}</Text>
            </View>
        </TouchableOpacity>
    )

    const renderCategoryButton = ({ item }) => (
        <TouchableOpacity
            style={[styles.categoryButton, selectedCategory === item && styles.selectedCategoryButton]}
            onPress={() => setSelectedCategory(item)}
        >
            <Text style={[styles.categoryButtonText, selectedCategory === item && styles.selectedCategoryButtonText]}>
                {item.charAt(0).toUpperCase() + item.slice(1).replace('-', ' ')}
            </Text>
        </TouchableOpacity>
    )

    if (loading && products.length === 0) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#007AFF" />
            </View>
        )
    }

    return (
        <SafeAreaView style={styles.container}>
            <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
            
            <FlatList
                data={categories}
                renderItem={renderCategoryButton}
                keyExtractor={(item) => item}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.categoryList}
            />

            {loading ? (
                <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color="#007AFF" />
                </View>
            ) : (
                <FlatList
                    data={products}
                    renderItem={renderProduct}
                    keyExtractor={(item) => item.id.toString()}
                    contentContainerStyle={styles.listContainer}
                    numColumns={2}
                    columnWrapperStyle={styles.columnWrapper}
                />
            )}
        </SafeAreaView>
    )
}

export default Products

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f5f5f5',
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#f5f5f5',
    },
    listContainer: {
        padding: 10,
    },
    columnWrapper: {
        justifyContent: 'space-between',
        marginBottom: 10
    },
    productItem: {
        flex: 0.5,
        backgroundColor: '#ffffff',
        borderRadius: 12,
        padding: 15,
        marginHorizontal: 5,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 3,
        elevation: 3,
    },
    productImage: {
        width: 120,
        height: 120,
        resizeMode: 'contain',
        marginBottom: 10,
        backgroundColor: '#ffffff',
        borderRadius: 8
    },
    productInfo: {
        width: '100%',
    },
    productTitle: {
        fontSize: 14,
        fontWeight: '500',
        marginBottom: 5,
        color: '#333333',
        height: 40,
    },
    productPrice: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#FF9500',
    },
    categoryList: {
        paddingHorizontal: 10,
        paddingVertical: 10,
        backgroundColor: '#ffffff',
        borderBottomWidth: 1,
        borderBottomColor: '#eeeeee',
    },
    categoryButton: {
        backgroundColor: '#eeeeee',
        paddingVertical: 8,
        paddingHorizontal: 15,
        borderRadius: 20,
        marginRight: 10,
        minWidth: 100, 
        height: 38,
        justifyContent: 'center',
        alignItems: 'center',
    },
    selectedCategoryButton: {
        backgroundColor: '#007AFF',
    },
    categoryButtonText: {
        fontSize: 14,
        color: '#666666',
        fontWeight: '500',
    },
    selectedCategoryButtonText: {
        color: '#ffffff',
        fontWeight: 'bold',
    }
})