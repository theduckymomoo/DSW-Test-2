import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  SafeAreaView,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import React, { useState, useCallback } from "react";
import { MaterialIcons } from '@expo/vector-icons';
import { auth } from '../firebaseConfig'
import { signInWithEmailAndPassword } from 'firebase/auth'

const validateEmail = (email) => {
    const re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    return re.test(String(email).toLowerCase());
}

const InputField = React.memo(({
  icon,
  label,
  placeholder,
  value,
  onChangeText,
  onBlur,
  secureTextEntry = false,
  keyboardType = "default",
  error,
  showError = true,
  rightIcon,
  fieldName,
  isLoading,
  isFocused,
  onFocus
}) => (
  <View style={styles.field}>
    <View style={styles.fieldHeader}>
      <MaterialIcons name={icon} size={20} color={styles.icon.color} />
      <Text style={styles.fieldLabel}>{label}</Text>
    </View>
    <View style={styles.inputContainer}>
      <TextInput
        style={[
          styles.input,
          isFocused && styles.inputFocused,
          error && showError && styles.inputError,
          rightIcon && styles.inputWithIcon
        ]}
        placeholder={placeholder}
        placeholderTextColor="#999999"
        value={value}
        onChangeText={onChangeText}
        onFocus={() => onFocus(fieldName)}
        onBlur={() => onBlur(fieldName, value)}
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType}
        autoCapitalize="none"
        autoCorrect={false}
        editable={!isLoading}
        returnKeyType={label === "Email" ? "next" : "done"}
        blurOnSubmit={label !== "Email"}
      />
      {rightIcon && (
        <TouchableOpacity style={styles.inputIcon} onPress={rightIcon.onPress}>
          <MaterialIcons 
            name={rightIcon.iconName} 
            size={20} 
            color={isFocused ? styles.icon.color : '#aaaaaa'} 
          />
        </TouchableOpacity>
      )}
    </View>
    {error && showError && (
      <Text style={styles.errorText}>{error}</Text>
    )}
  </View>
));


const Login = ({ navigation }) => {
    const [formData, setFormData] = useState({
        email: "",
        password: "",
    });
    const [errors, setErrors] = useState({});
    const [touched, setTouched] = useState({});
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false)
    const [focusedField, setFocusedField] = useState(null);

    const validateField = useCallback((field, value) => {
        let error = null;
        if (!value.trim()) {
            error = `${field.charAt(0).toUpperCase() + field.slice(1)} is required.`;
        } else if (field === "email" && !validateEmail(value)) {
            error = "Please enter a valid email address.";
        }
        setErrors(prev => ({ ...prev, [field]: error }));
        return error === null;
    }, []);

    const validateForm = useCallback(() => {
        const emailValid = validateField("email", formData.email);
        const passwordValid = validateField("password", formData.password);
        setTouched({ email: true, password: true });
        return emailValid && passwordValid;
    }, [formData, validateField]);

    const handleEmailChange = useCallback((text) => {
        setFormData(prev => ({ ...prev, email: text }));
    }, []);

    const handlePasswordChange = useCallback((text) => {
        setFormData(prev => ({ ...prev, password: text }));
    }, []);

    const handleBlur = useCallback((field, value) => {
        setTouched(prev => ({ ...prev, [field]: true }));
        setFocusedField(null);
        validateField(field, value);
    }, [validateField]);

    const handleFocus = useCallback((field) => {
        setFocusedField(field);
    }, []);

    const handleLogin = async () => {
        if (!validateForm()) return;

        setLoading(true)
        try {
            await signInWithEmailAndPassword(auth, formData.email.trim().toLowerCase(), formData.password)
            Alert.alert("Success", "User Logged In")
        } catch (error) {
            Alert.alert("Login Failed", "Invalid email or password. Please check your credentials and try again.")
        } finally {
            setLoading(false)
        }
    }

    const isFormValid = formData.email.trim().length > 0 && formData.password.length > 0;

    return (
        <SafeAreaView style={styles.container}>
            <StatusBar barStyle="dark-content" backgroundColor="#ffffff" />
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={styles.content}
            >
                {/* Header */}
                <View style={styles.header}>
                    <Text style={styles.title}>Welcome Back</Text>
                    <Text style={styles.subtitle}>Sign in to ShopEZ</Text>
                </View>

                {/* Form */}
                <View style={styles.form}>
                    <InputField
                        icon="mail-outline"
                        label="Email"
                        placeholder="john@example.com"
                        value={formData.email}
                        onChangeText={handleEmailChange}
                        onFocus={handleFocus}
                        onBlur={handleBlur}
                        fieldName="email"
                        keyboardType="email-address"
                        error={errors.email}
                        showError={touched.email}
                        isFocused={focusedField === 'email'}
                        isLoading={loading}
                    />

                    <InputField
                        icon="lock-outline"
                        label="Password"
                        placeholder="Enter your password"
                        value={formData.password}
                        onChangeText={handlePasswordChange}
                        onFocus={handleFocus}
                        onBlur={handleBlur}
                        fieldName="password"
                        secureTextEntry={!showPassword}
                        error={errors.password}
                        showError={touched.password}
                        isFocused={focusedField === 'password'}
                        rightIcon={{
                            iconName: showPassword ? "visibility-off" : "visibility",
                            onPress: () => setShowPassword(!showPassword)
                        }}
                        isLoading={loading}
                    />
                </View>

                {/* Submit Button */}
                <TouchableOpacity
                    style={[
                        styles.submitBtn,
                        (loading || !isFormValid) && styles.submitBtnDisabled
                    ]}
                    onPress={handleLogin}
                    disabled={loading || !isFormValid}
                >
                    {loading ? (
                        <ActivityIndicator color="#ffffff" />
                    ) : (
                        <Text style={styles.submitBtnText}>Sign In</Text>
                    )}
                </TouchableOpacity>

                {/* Footer */}
                <View style={styles.footer}>
                    <Text style={styles.footerText}>Don't have an account? </Text>
                    <TouchableOpacity
                        onPress={() => navigation.navigate('Signup')}
                        disabled={loading}
                    >
                        <Text style={styles.footerLink}>Sign Up</Text>
                    </TouchableOpacity>
                </View>
            </KeyboardAvoidingView>
        </SafeAreaView>
    )
}

export default Login

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#ffffff',
    },
    content: {
        flex: 1,
        paddingHorizontal: 24,
        justifyContent: 'center',
    },
    header: {
        alignItems: 'center',
        marginBottom: 48,
    },
    title: {
        fontSize: 32,
        fontWeight: '800',
        color: '#333333',
        marginBottom: 8,
    },
    subtitle: {
        fontSize: 16,
        color: '#666666',
    },
    form: {
        marginBottom: 24,
    },
    field: {
        marginBottom: 20,
    },
    fieldHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 8,
    },
    fieldLabel: {
        fontSize: 14,
        color: '#666666',
        fontWeight: '600',
        marginLeft: 8,
    },
    icon: {
        color: '#007AFF',
    },
    inputContainer: {
        position: 'relative',
    },
    input: {
        height: 44,
        borderWidth: 1,
        borderColor: '#dddddd',
        borderRadius: 10,
        paddingHorizontal: 12,
        fontSize: 16,
        color: '#333333',
        backgroundColor: '#f9f9f9',
    },
    inputFocused: {
        borderColor: '#007AFF',
        borderWidth: 2,
    },
    inputError: {
        borderColor: '#FF3B30',
        backgroundColor: 'rgba(255, 59, 48, 0.1)',
    },
    inputWithIcon: {
        paddingRight: 45,
    },
    inputIcon: {
        position: 'absolute',
        right: 12,
        top: '50%',
        transform: [{ translateY: -10 }],
        padding: 4,
    },
    errorText: {
        color: '#FF3B30',
        fontSize: 12,
        marginTop: 4,
        marginLeft: 4,
    },
    submitBtn: {
        backgroundColor: '#007AFF',
        height: 54,
        borderRadius: 12,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 32,
    },
    submitBtnDisabled: {
        opacity: 0.6,
    },
    submitBtnText: {
        color: '#ffffff',
        fontSize: 16,
        fontWeight: '700',
    },
    footer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
    },
    footerText: {
        color: '#666666',
        fontSize: 16,
    },
    footerLink: {
        color: '#007AFF',
        fontSize: 16,
        fontWeight: '700',
    },
});