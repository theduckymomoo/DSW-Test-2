import React, { useState, useEffect } from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { createStackNavigator } from '@react-navigation/stack'
import { ActivityIndicator, View, StyleSheet } from 'react-native'
import { auth } from './firebaseConfig'
import { onAuthStateChanged } from 'firebase/auth'

import LandingScreen from './screens/Landing'
import LoginScreen from './screens/Login'
import SignupScreen from './screens/Signup'
import ProductsScreen from './screens/Products'
import ProductDetailScreen from './screens/ProductDetail'
import CartScreen from './screens/Cart'

const Stack = createStackNavigator()

const AuthStack = () => (
    <Stack.Navigator screenOptions={{
        headerStyle: { backgroundColor: '#f5f5f5' },
        headerTintColor: '#007AFF',
        headerTitleStyle: { fontWeight: 'bold' },
    }}>
        <Stack.Screen name="Login" component={LoginScreen} options={{ title: 'ShopEZ Login' }} />
        <Stack.Screen name="Signup" component={SignupScreen} options={{ title: 'ShopEZ Sign Up' }} />
    </Stack.Navigator>
)

const AppStack = () => (
    <Stack.Navigator screenOptions={{
        headerStyle: { backgroundColor: '#f5f5f5' },
        headerTintColor: '#007AFF',
        headerTitleStyle: { fontWeight: 'bold' },
    }}>
        <Stack.Screen name="Products" component={ProductsScreen} />
        <Stack.Screen name="ProductDetail" component={ProductDetailScreen} options={{ title: 'Product Detail' }} />
        <Stack.Screen name="Cart" component={CartScreen} options={{ title: 'Your Cart' }} />
    </Stack.Navigator>
)

const App = () => {
    const [initializing, setInitializing] = useState(true)
    const [user, setUser] = useState(null)

    useEffect(() => {
        const subscriber = onAuthStateChanged(auth, (user) => {
            setUser(user)
            if (initializing) setInitializing(false)
        })
        return subscriber
    }, [])

    if (initializing) {
        return (
            <View style={styles.container}>
                <LandingScreen />
            </View>
        )
    }

    return (
        <NavigationContainer>
            {user ? <AppStack /> : <AuthStack />}
        </NavigationContainer>
    )
}

export default App

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    }
})