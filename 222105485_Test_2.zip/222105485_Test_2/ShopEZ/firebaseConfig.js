import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyA0i3m6CGWeLk14GUDgKmHJ88rhOJnYEGg",
  authDomain: "dsw-test-2.firebaseapp.com",
  projectId: "dsw-test-2",
  storageBucket: "dsw-test-2.firebasestorage.app",
  messagingSenderId: "630494890739",
  appId: "1:630494890739:web:e64cc312b7eb05180e8586"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app)
export const database = getDatabase(app)